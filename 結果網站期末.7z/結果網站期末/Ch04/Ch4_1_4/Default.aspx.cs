﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int[] card = new int[2];
        Random rd = new Random();
        card[0] = rd.Next(1, 13);   // 取得亂數值
        card[1] = rd.Next(1, 13);
        Button btnButton = (Button)sender;
        if (btnButton.ID == "Button1")
        {
            Button1.Text = "* " + card[0] + "點";
            Button2.Text = card[1] + "點";
        }
        if (btnButton.ID == "Button2")
        {
            Button1.Text = card[0] + "點";
            Button2.Text = "* " + card[1] + "點";
        }
    }
}