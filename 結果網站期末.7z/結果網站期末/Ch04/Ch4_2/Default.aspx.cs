﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    // Page物件的Load事件
    protected void Page_Load(object sender, EventArgs e)
    {
        Page.Title = "Ch4_2";
        showEvent("Page_Load事件觸發...<br/>");
    }
    // Page物件的PreInit事件
    protected void Page_PreInit(object sender, EventArgs e)
    {
        showEvent("Page_PreInit事件觸發...<br/>");
    }
    // Page物件的PreRender事件
    protected void Page_PreRender(object sender, EventArgs e)
    {
        showEvent("Page_PreRender事件觸發...<br/>");
    }
    // Page物件的UnLoad事件
    protected void Page_Unload(object sender, EventArgs e)
    {
        showEvent("Page_UnLoad事件觸發...<br/>");
    }
    // 顯示事件的執行過程
    void showEvent(string str)
    {
        lblOutput.Text += str;
    }
}