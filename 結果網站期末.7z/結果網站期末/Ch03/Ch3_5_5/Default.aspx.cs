﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int i, total = 0, j = 10;
        for (i = 1; i <= 100; i++)
        {
            if (i > j) break;
            if (i % 2 == 0) continue;
            total += i;
        }
        lblOutput.Text = "1加至10的奇數和: " + total + "<br/>";
    }
}