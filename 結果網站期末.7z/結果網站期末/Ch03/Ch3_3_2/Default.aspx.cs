﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        const double PI = 3.1415926; // 常數宣告
        double area = 25.0;   // 變數宣告與初值
        string name = "陳會安", title;
        uint height, width;
        title = "我的\"個人\"首頁"; // 指定敘述
        height = 500u;
        width = height;
        area = PI * 4 * 4;
        lblOutput.Text = "姓名: " + name + "<br/>" +
                         "標題: " + title + "<br/>" +
                         "高:" + height + "<br/>" +
                         "寬:" + height + "<br/>" +
                         "面積:" + area + "<br/>";
    }
}