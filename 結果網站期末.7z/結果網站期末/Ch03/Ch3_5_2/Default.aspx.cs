﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int age = 40;
        char grade = 'C';
        string str = "";
        if (age <= 18)  // if/else/if條件敘述
            str = "學生票：12元<br/>";
        else
            if (age >= 65)
            str = "敬老票：8元<br/>";
        else
            str = "普通票：15元<br/>";
        lblOutput.Text = str;
        switch (grade)  // switch條件敘述
        {
            case 'A':
                str = "超過80分<br/>";
                break;
            case 'B':
                str = "70~79分<br/>";
                break;
            case 'C':
                str = "60~69分<br/>";
                break;
            default:
                str = "低於60分<br/>";
                break;
        }
        lblOutput.Text += str;
    }
}