﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int i, total = 0;
        for (i = 1; i <= 15; i++)  // for迴圈
        {
            lblOutput.Text += i + " ";
            total += i;
        }
        lblOutput.Text += "<br/>1加到15的總和: " + total + "<br/>";
        int[] scores = { 56, 85, 78 };
        foreach (int myScore in scores)  // foreach迴圈
        {
            lblOutput.Text += myScore + "<br/>";
        }
    }
}