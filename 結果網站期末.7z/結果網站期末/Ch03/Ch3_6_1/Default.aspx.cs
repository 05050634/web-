﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }
    // 顯示重複訊息文字
    void ShowRepeatMessage(string msg, int times)
    {
        int i;
        for (i = 1; i <= times; i++)
        {
            lblOutput.Text += msg + "<br/>";
        }
    }
    // 轉換溫度
    float ConvertTemperature(int C)
    {
        float F;
        F = (9.0F * C) / 5.0F + 32.0F;
        return F;
    }

    protected void Button1_Click(object sender, EventArgs e)
    {   // 呼叫C#函數
        ShowRepeatMessage("擁有參數的函數", 2);
        float temp;
        temp = ConvertTemperature(100);
        lblOutput.Text += "攝氏100轉換成華氏: " + temp;

    }
}