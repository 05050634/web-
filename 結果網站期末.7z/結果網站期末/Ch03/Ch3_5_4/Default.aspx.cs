﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int i = 1;
        int total = 0;
        while (i <= 15)  // while迴圈
        {
            lblOutput.Text += i + " ";
            total += i;
            i += 1;
        }
        lblOutput.Text += "<br/>1加到15的總和: " + total + "<br/>";
        i = 1; total = 0;
        do  // do/while迴圈
        {
            lblOutput.Text += i + " ";
            total += i;
            i += 1;
        } while (i <= 15);
        lblOutput.Text += "<br/>1加到15的總和: " + total + "<br/>";
    }
}