﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        int grade = 75, length = 110, hour = 22;
        if (grade >= 60)  // if條件敘述
        {
            lblOutput.Text += "成績及格! ";
            lblOutput.Text += "學生成績: " + grade + "<br/>";
        }
        if (length > 120)  // if/else條件敘述
            lblOutput.Text += "購買全票!<br/>";
        else
            lblOutput.Text += "購買半票!<br/>";
        hour = (hour >= 12) ? hour - 12 : hour; // 條件運算子
        lblOutput.Text += "12小時制: " + hour;
    }
}