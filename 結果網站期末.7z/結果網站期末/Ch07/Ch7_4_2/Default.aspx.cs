﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        string name = "江小魚";
        // 新增Cookie
        Response.Cookies["User"].Value = Server.UrlEncode(name);
        DateTime dtDay = DateTime.Today.AddDays(10);
        Response.Cookies["User"].Expires = dtDay;
        lblOutput.Text = "已經成功建立Cookie!";
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        Response.Redirect("Default2.aspx"); // 轉址
    }
}