﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name;
        // 檢查Cookie是否存在
        if (Request.Cookies["User"] != null)
        {
            name = Server.UrlDecode(Request.Cookies["User"].Value);
            lblOutput.Text = "Cookie值：" + name;
        }
    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        DateTime dtDay = DateTime.Today.AddDays(-365);
        Response.Cookies["User"].Expires = dtDay; // 刪除Cookie
        Response.Redirect("Default.aspx");
    }
}