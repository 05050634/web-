﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        Response.Cookies["User"]["Name"] = Server.UrlEncode("陳會安");
        Response.Cookies["User"]["ID"] = "1234";
        Response.Cookies["User"].Expires = DateTime.Today.AddDays(10);
        lblOutput.Text = "成功建立多鍵Cookie!";
    }

    protected void Button2_Click(object sender, EventArgs e)
    {
        string name, no;
        if (Request.Cookies["User"] != null)
        {
            name = Server.UrlDecode(Request.Cookies["User"]["Name"]);
            no = Request.Cookies["User"]["ID"];
            lblOutput.Text = "名稱:" + name + "<br/>";
            lblOutput.Text += "學號:" + no + "<br/>";
        }
        else
        {
            lblOutput.Text = "多鍵Cookie不存在!";
        }
    }

    protected void Button3_Click(object sender, EventArgs e)
    {
        DateTime dtDay = DateTime.Today.AddDays(-365);
        Response.Cookies["User"].Expires = dtDay;
        lblOutput.Text = "成功刪除多鍵Cookie!";
    }
}