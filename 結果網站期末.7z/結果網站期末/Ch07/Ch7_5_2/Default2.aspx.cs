﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class Default2 : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string name, password;
        lblOutput.Text = "Session ID:" + Session.SessionID + "<br/>";
        if (Session["UserName"] != null)
        {
            // 取得Session變數值
            name = Session["UserName"].ToString();
            password = Session["UserPassword"].ToString();
            // 顯示取得的Session變數值            
            lblOutput.Text += "名稱: " + name + "<br/>";
            lblOutput.Text += "密碼: " + password + "<br/>";
            Session.Abandon(); // 放棄Session
        }
    }
}