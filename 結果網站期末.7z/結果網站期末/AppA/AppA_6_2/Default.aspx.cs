﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 宣告ArrayList物件
        ArrayList products = new ArrayList();
        int i = 0;
        // 新增元素
        products.Add("MP3播放器");
        products.Add("數位相機");
        products.Add("筆記型電腦");
        // 使用for迴圈
        for (i = 0; i < products.Count; i++)
        {
            lblOutput.Text += "[" + i + ":" + products[i] + "]";
        }
        i = products.IndexOf("數位相機");
        lblOutput.Text += "<br/>搜尋[數位相機]的位置: " + i + "<br/>";
        products.Insert(1, "照像手機"); // 插入元素
        products.Insert(3, "液晶螢幕");
        products.Remove("筆記型電腦"); // 刪除元素
        products.RemoveAt(0);
        // 使用foreach/in迴圈
        foreach (string item in products)
        {
            lblOutput.Text += "[" + item + "]";
        }
        products.Clear(); // 清除ArrayList
    }
}