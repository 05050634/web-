﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;
using System.Collections;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        // 宣告Hashtable物件
        Hashtable accounts = new Hashtable();
        int i = 0;
        // 新增元素
        accounts.Add("hueyan", "1234");
        accounts.Add("jane", "5678");
        accounts.Add("mary", "1345");
        accounts.Add("tom", "8978");
        // 使用foreach/in迴圈
        foreach (string user in accounts.Keys)
        {
            lblOutput.Text += "[" + user + ":" + accounts[user] + "]";
        }
        // 搜尋jane後刪除
        if (accounts.ContainsKey("jane"))
        {
            lblOutput.Text += "<br/>找到jane準備刪除....<br/>";
            accounts.Remove("jane");
            lblOutput.Text += "刪除結果: ";
            foreach (string user in accounts.Keys)
            {
                lblOutput.Text += "[" + user + ":" + accounts[user] + "]";
            }
        }
        accounts.Clear(); // 清除Hashtable
    }
}