﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{
    protected void Page_Load(object sender, EventArgs e)
    {
        string[] name = new string[5]; // 宣告一維陣列
        int x = 10;
        name[x] = "ASP.NET";   // 測試的錯誤程式碼
        lblOutput.Text = name[x];
    }
}