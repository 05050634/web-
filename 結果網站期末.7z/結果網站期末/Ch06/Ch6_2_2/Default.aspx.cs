﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.UI;
using System.Web.UI.WebControls;

public partial class _Default : System.Web.UI.Page
{

    int i = 0;
    protected void Page_Load(object sender, EventArgs e)
    {

    }

    protected void Button1_Click(object sender, EventArgs e)
    {
        //int i = 0;

        if (Page.IsValid)
        {
            // 驗證成功顯示控制項的值
            lblOutput.Text = "密碼: " + txtPass1.Text + "<br/>";
            lblOutput.Text += "數量: " + txtQuantity.Text;
        }
        else
        {
            //i++;

            //if(i == 3)
            //{
                gg.Text = "你輸錯"; 
            //}
        }
    }
}