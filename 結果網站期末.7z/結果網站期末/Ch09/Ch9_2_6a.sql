SELECT * FROM Courses 
ORDER BY credits DESC
















