SELECT MIN(credits) AS �̧C�Ǥ� FROM Courses 
WHERE c_no LIKE '%2%'














