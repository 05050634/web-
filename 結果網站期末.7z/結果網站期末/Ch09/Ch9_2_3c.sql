SELECT * FROM Courses
WHERE credits BETWEEN 2 AND 3





