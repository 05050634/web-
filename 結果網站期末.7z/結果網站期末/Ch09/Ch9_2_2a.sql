SELECT * FROM Students 
WHERE sid = 'S002'

