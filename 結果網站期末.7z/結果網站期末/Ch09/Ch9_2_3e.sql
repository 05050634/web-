SELECT * FROM Students
WHERE sid NOT IN ('S003', 'S005', 'S001')







