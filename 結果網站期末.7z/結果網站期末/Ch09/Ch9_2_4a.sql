SELECT * FROM Classes
WHERE (grade * 1.1) > 80











