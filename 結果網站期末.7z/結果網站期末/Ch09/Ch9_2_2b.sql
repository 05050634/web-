SELECT * FROM Courses
WHERE credits < 4


