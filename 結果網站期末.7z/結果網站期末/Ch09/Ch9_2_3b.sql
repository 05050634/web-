SELECT * FROM Courses 
WHERE c_no LIKE 'CS1__'




