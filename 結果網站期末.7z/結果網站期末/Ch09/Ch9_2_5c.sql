SELECT MAX(credits) AS �̰��Ǥ� FROM Courses 
WHERE c_no LIKE '%2%'













