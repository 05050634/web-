SELECT * FROM Courses
WHERE c_no LIKE '%1%' AND title LIKE N'%�{��%'








