SELECT COUNT(*) AS �ҵ{�� FROM Courses
WHERE credits > 3












