SELECT DISTINCT credits FROM Courses
