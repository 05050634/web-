SELECT * FROM Courses
WHERE c_no LIKE '%1%' OR title LIKE N'%�{��%'









