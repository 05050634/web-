SELECT * FROM Students 
WHERE birthday ='1967-09-03'



