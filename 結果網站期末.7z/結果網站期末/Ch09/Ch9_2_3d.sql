SELECT * FROM Students
WHERE sid IN ('S003', 'S005', 'S001')






